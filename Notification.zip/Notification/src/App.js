import { useState } from 'react';
import Button from './components/button/Button'
import Notification from './components/notify/Notification'
import styles from './App.module.css'

function App() {
  const [list, setList] = useState([]);
  let notificationProperties = null;

  const showToast = type => {
       switch(type) {
      case 'success':
        notificationProperties = {
          id: list.length+1,
          title: 'Success',
          description: 'This is a success component',
          backgroundColor: '#5cb85c',
          
        }
        break;
      case 'danger':
        notificationProperties = {
          id: list.length+1,
          title: 'Danger',
          description: 'This is a danger component',
          backgroundColor: 'red',
          position: 'inherit',
          left: '0',
          top: list.length+1,    
          marginTop: list.length+1
          
          
          
        }
        break;
      case 'info':
        notificationProperties = {
          id: list.length+1,
          title: 'Info',
          description: 'This is a info component',
          backgroundColor: '#5bc0de'
        
        }
        break;
      case 'warning':
        notificationProperties = {
          id: list.length+1,
          title: 'Warning',
          description: 'This is a warning component',
          backgroundColor: '#f0ad4e',
          
        }
        break;
      default:
        notificationProperties = [];
    }
    setList([...list, notificationProperties]);
  };

  return (
    <div className={styles.root}>
      <h1>React Notification Component</h1>
      <div className={styles.buttons}>
        <Button handleClick={() => showToast('success')}>Success</Button>
        <Button handleClick={() => showToast('danger')}>Danger</Button>
        <Button handleClick={() => showToast('info')}>Info</Button>
        <Button handleClick={() => showToast('warning')}>Warning</Button>
      </div>
      <Notification toastlist={list} position="buttom-right" setList={setList} />
    </div>
  );
}

export default App;
